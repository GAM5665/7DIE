ResetCharacter 角色自助重置 Mod —— 安装说明
================================================

【重要】版本要求
  本 Mod 的 DLL 是针对 7 Days to Die V3.4 专用服程序集编译的。
  目标服务器必须是 V3.4（同为 V3.4 即可，无需考虑客户端）。
  版本不一致（如 V2.x / A21 / 更新的 V3.x）可能导致 Mod 不加载或聊天指令失效。
  若目标服务器是其他版本，需要拿该版本的 Assembly-CSharp.dll 重新编译源码
  （源码工程：ResetCharacterMod.zip，用 build.bat 指定 GAME_DIR 编译）。

【安装步骤】
  1. 把压缩包里的 ResetCharacter 整个文件夹放到目标服务器的 Mods 目录下，
     最终路径应为：
        <服务器目录>\Mods\ResetCharacter\
            ├── ResetCharacter.dll
            ├── ModInfo.xml
            └── Config\config.json
  2. 用文本编辑器打开 <服务器目录>\serverconfig.xml，确认：
        <property name="EACEnabled" value="false" />
     EAC 开启时 Mod 不会加载。
  3. 需要管理员在控制台用 resetchar <玩家> 帮别人重置时，把该管理员加入
        C:\Users\<用户>\AppData\Roaming\7DaysToDie\Saves\serveradmin.xml
     例：<user platform="EOS" userid="<管理员EOS_ID>" name="<名字>" permission_level="0" />
  4. 启动服务器，日志出现以下行即加载成功：
        [ResetChar] Loaded. Chat: /resetchar | Console: resetchar

【使用方式】
  玩家自助： 游戏内聊天输入 /resetchar 发起，10 秒后自动重置（有二次确认）
              /resetchar confirm  立即确认
              /resetchar cancel   取消
  管理员：   控制台输入 resetchar <玩家名或ID>

【效果】
  只清角色档案（等级/技能/背包），保留建筑、容器、工作台、领地石归属和地图探索。
  重生点优先睡袋、其次最后位置，都没有才走游戏默认出生区；与领地石无关。
  删档前自动备份角色档案到：
        <存档目录>\ResetCharacterBackups\
  每个玩家保留最近 3 份（可在 Config\config.json 里改 BackupRetentionCount）。

【配置】 Config\config.json
  ChatCommand           聊天指令名（默认 resetchar）
  AdminConsoleCommand   管理员控制台指令名（默认 resetchar）
  ResetDelaySeconds     发起后延迟多少秒执行（默认 10）
  BackupRetentionCount  每玩家保留的备份份数（默认 3）
